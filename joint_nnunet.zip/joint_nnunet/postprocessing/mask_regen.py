import numpy as np
import skimage.measure as measure
import skimage.morphology as morphology
import SimpleITK as sitk
def load_nii(path) -> np.array:
    volume = sitk.ReadImage(path)
    spacing = volume.GetSpacing()
    size = volume.GetSize()

    return sitk.GetArrayFromImage(volume)

def message_out(msg_contents:list):
    msg = ''
    for msg_name, msg_content in msg_contents:
        msg += '[{}: {}] '.format(msg_name, msg_content)
        
    message_str = '>>>MessageOut: {}'.format(msg)
    print(message_str)

def save_nii_float32(out_path, volume:np.array, nii_type=np.float32):
    
    assert out_path.split('.')[-1] in ['gz', 'nii'], message_out([('Error','Save Type Error, need nii or nii.gz!')])
    sitk_volume = sitk.GetImageFromArray(volume.astype(nii_type))
    sitk.WriteImage(sitk_volume, out_path)
    message_out([('save nift in', out_path)])
    
    return True

def save_nii_int16(out_path, volume:np.array, nii_type=np.int16):
    
    assert out_path.split('.')[-1] in ['gz', 'nii'], message_out([('Error','Save Type Error, need nii or nii.gz!')])
    sitk_volume = sitk.GetImageFromArray(volume.astype(nii_type))
    sitk.WriteImage(sitk_volume, out_path)
    message_out([('save nift in', out_path)])
    
    return True
def reconstruct_lesion_border(pet_suv_img, lesion_mask):
    
    lesion_labeled_mask, lesion_num = measure.label(
        lesion_mask, connectivity=3, return_num=True
    )
    
    lesion_labeled_mask = morphology.dilation(lesion_labeled_mask, 
                                              morphology.ball(1))
    
    lesion_mask_regionprops = measure.regionprops(
        lesion_labeled_mask, intensity_image=pet_suv_img)
    
    new_mask = np.zeros(lesion_mask.shape, dtype=lesion_mask.dtype)
    for idx, single_lesion_regprop in enumerate(lesion_mask_regionprops):
        lesion_id = idx+1
        #single_lesion_bbox = single_lesion_regprop.bbox
        #print(single_lesion_regprop.bbox)
        z, y, x, height, length, width = single_lesion_regprop.bbox
        single_lesion_mask = np.zeros(pet_suv_img.shape, dtype=pet_suv_img.dtype)
        
        single_lesion_mask[z:height, y:length, x:width]=pet_suv_img[z:height, y:length, x:width]

        # k1 = calc_hist_slope(single_lesion_mask, 30, 90)
        # k2 = calc_hist_slope(single_lesion_mask, 10, 40)
        
        # if k1<k2:
        #     continue

        suv_threshold = 0.4*np.max(single_lesion_mask)
        single_lesion_mask[single_lesion_mask<suv_threshold]=0
        
        single_lesion_mask[single_lesion_mask>0]=1

        new_mask = np.bitwise_or(new_mask, single_lesion_mask.astype(lesion_mask.dtype)) 
    
    return new_mask


if __name__ == "__main__":
    path_pet=r'C:\Users\yuhang.shi\Desktop\psma_predict\psma_workspace\data\pet.nii.gz'
    pet_suv_img=load_nii(path_pet)

    path_mask=r'C:\Users\yuhang.shi\Desktop\psma_predict\psma_workspace\data\pet_mask.nii.gz'
    lesion_mask=load_nii(path_mask)

    lesion_mask_regen=reconstruct_lesion_border(pet_suv_img, lesion_mask)

    path_mask_regen=r'C:\Users\yuhang.shi\Desktop\psma_predict\psma_workspace\data\pet_mask_regen.nii.gz'
    save_nii_int16(path_mask_regen,lesion_mask_regen)
